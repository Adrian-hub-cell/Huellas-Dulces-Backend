# Huellas Dulces — Frontend

Aplicación web SPA de **Huellas Dulces**, desarrollada con Angular.

## Tecnologías
- Angular 21.
- TypeScript.
- Nginx para servir la aplicación en el contenedor/entorno web.
- GitHub Actions para integración continua.

## Ejecución local
Requisitos: Node.js 22 y npm.

```bash
npm install
npm start
```

Si el proyecto no define el script `start`, utiliza el script de desarrollo declarado en `package.json` (por ejemplo, `ng serve`).

## Construcción
```bash
npm ci
npm run build
```

Consulta `package.json` para conocer los scripts exactos de pruebas, lint y compilación disponibles en esta versión del proyecto.

## Integración con backend
La URL del API debe configurarse mediante el mecanismo de entornos de Angular utilizado por el proyecto. No guardar credenciales ni secretos en el código del navegador.

## Pruebas y CI
El workflow de GitHub Actions está en `.github/workflows/ci.yml`. En las ejecuciones revisadas, las cuatro ejecuciones más recientes compartidas aparecieron como **completed successfully**; la más reciente identificada fue CI #7.

## Despliegue
- Repositorio: https://github.com/Adrian-hub-cell/Huellas-Dulces-Frontend.
- Aplicación pública: https://huellas-dulces-frontend.onrender.com

El frontend fue abierto y confirmado por el usuario durante la preparación de la entrega.

## Seguridad
No incluir secretos en variables compiladas para el navegador. Las operaciones protegidas deben delegarse al backend y utilizar HTTPS.
