# Huellas Dulces — Backend

API REST para la gestión de productos de **Huellas Dulces**, desarrollada con Spring Boot y Java.

## Tecnologías
- Java 25 y Spring Boot 4.
- PostgreSQL y Spring Data JPA.
- Seguridad basada en JWT.
- MongoDB y Redis configurados para capacidades complementarias.
- Maven Wrapper.
- JaCoCo y SonarCloud para análisis de calidad.
- Docker y GitHub Actions para automatización.

> La presencia de una tecnología en esta lista indica que forma parte de la configuración del proyecto; su disponibilidad efectiva depende de la configuración del entorno.

## Ejecución local
Requisitos: JDK 25 y conexión a los servicios configurados en el perfil que se vaya a utilizar.

En Windows PowerShell:
```powershell
.\mvnw.cmd clean verify
.\mvnw.cmd spring-boot:run
```

## API
- Autenticación: `POST /api/v1/auth/login`
- Productos: `/api/v1/products`
- Documentación OpenAPI: `/v3/api-docs`
- Estado de la aplicación (Actuator): `/actuator/health`

La autorización de los endpoints depende de las reglas definidas en la configuración de Spring Security.

## Configuración
La configuración de producción utiliza variables de entorno para credenciales y conexiones. No publiques secretos en el repositorio. Configura, como mínimo, las variables requeridas por `application-prod.properties` en el proveedor de despliegue.

## Pruebas y calidad
El pipeline de GitHub Actions ejecuta la verificación Maven y genera el reporte de JaCoCo. El panel de SonarCloud reportado para el proyecto mostró:
- Quality Gate: **Passed**
- Cobertura: **89,6 %**
- Duplicaciones: **0,0 %**
- Calificaciones de seguridad, confiabilidad y mantenibilidad: **A**

Consulta el workflow en la pestaña **Actions** del repositorio.

## Despliegue
- Repositorio: https://github.com/Adrian-hub-cell/Huellas-Dulces-Backend
- Servicio Render: https://huellas-dulces-backend.onrender.com

**Estado conocido al preparar esta documentación (13-11-2026):** el panel de Render mostró el servicio backend como `Failed`. Por tanto, el enlace se incluye como referencia de despliegue, pero no se declara que la API esté operativa públicamente hasta verificar un estado saludable.

## CI/CD
Workflow ubicado en `.github/workflows/ci.yml`. Según la configuración revisada, contempla compilación/verificación con Java 25, JaCoCo, análisis SonarCloud y publicación de imagen Docker con etiquetas `v1.0.0` y `latest`.

## Seguridad
- No subir `.env`, contraseñas, tokens ni claves privadas.
- Mantener secretos en variables protegidas del entorno de despliegue y GitHub Actions.
- Usar HTTPS en los entornos públicos.
