# Bitácora de uso de IA — Huellas Dulces

**Proyecto:** Huellas Dulces  
**Herramienta de apoyo:** Cursor AI  
**Fecha de consolidación:** 13 de noviembre de 2026

## Objetivo
Utilizar IA como apoyo para acelerar tareas de implementación, revisión, documentación y diagnóstico, manteniendo la responsabilidad de verificar los cambios en el repositorio y ejecutar las pruebas.

## Usos registrados / áreas de apoyo
- Apoyo en la organización y revisión de la estructura del backend Spring Boot.
- Asistencia con configuración de seguridad Spring Security y autenticación JWT.
- Apoyo en configuración de persistencia y variables de entorno para PostgreSQL y servicios complementarios.
- Revisión de workflows de GitHub Actions y automatización de compilación/verificación.
- Apoyo en configuración de despliegue y diagnóstico de Render.
- Elaboración y mejora de documentación técnica.

> Esta bitácora resume las áreas de trabajo asistidas por IA. No atribuye a Cursor cambios específicos que no estén comprobados en el historial del repositorio.

## Reglas de gobernanza propuestas
Se incluye un archivo `.cursorrules` con reglas para:
1. Respetar la arquitectura y el código existente.
2. Evitar reescrituras innecesarias.
3. Proteger secretos y credenciales.
4. Mantener separación de responsabilidades.
5. Añadir o actualizar pruebas al cambiar lógica.
6. Verificar compilación y pruebas antes de declarar un cambio terminado.
7. No inventar endpoints, funcionalidades ni resultados.

## Ejemplos de prompts reutilizables
- “Analiza primero la estructura existente de Huellas Dulces y propón el cambio mínimo que cumpla este requisito. No modifiques archivos todavía.”
- “Revisa este controlador y su servicio; identifica errores y conserva las convenciones actuales del proyecto.”
- “Genera pruebas para los casos exitosos, validaciones y errores. No afirmes que se ejecutaron hasta mostrar el resultado.”
- “Revisa este workflow de GitHub Actions y explica qué etapas ejecuta y qué evidencia produce.”
- “Documenta las variables de entorno necesarias, sin incluir valores secretos.”

## Validación humana
Las sugerencias de IA deben revisarse antes de integrarse. La evidencia válida de compilación, pruebas, análisis estático y despliegue es la salida de las herramientas correspondientes, no la respuesta de la IA.
