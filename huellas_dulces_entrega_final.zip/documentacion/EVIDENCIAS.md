# Índice de evidencias — Proyecto de Grado Huellas Dulces

## Repositorios
- Backend: https://github.com/Adrian-hub-cell/Huellas-Dulces-Backend
- Frontend: https://github.com/Adrian-hub-cell/Huellas-Dulces-Frontend.

## Integración continua
- Backend Actions: https://github.com/Adrian-hub-cell/Huellas-Dulces-Backend/actions
- Frontend Actions: https://github.com/Adrian-hub-cell/Huellas-Dulces-Frontend./actions

Evidencia compartida durante la preparación:
- Backend: última ejecución identificada #10, completada exitosamente.
- Frontend: última ejecución identificada #7, completada exitosamente.

## Calidad
- SonarCloud: Quality Gate **Passed**.
- Cobertura reportada: **89,6 %**.
- Duplicaciones reportadas: **0,0 %**.
- Calificaciones A en seguridad, confiabilidad y mantenibilidad.
- Adjuntar captura del panel SonarCloud y reporte JaCoCo descargado del pipeline si está disponible.

## Producción
- Frontend: https://huellas-dulces-frontend.onrender.com — abierto y confirmado por el usuario.
- Backend: https://huellas-dulces-backend.onrender.com
- Salud backend: https://huellas-dulces-backend.onrender.com/actuator/health

**Advertencia de transparencia:** Render mostró el backend como `Failed` durante la verificación del 13-11-2026. No presentar la API backend como operativa hasta resolver el fallo y confirmar `/actuator/health`.

## Evidencias que conviene adjuntar
1. Captura de GitHub Actions backend en verde.
2. Captura de GitHub Actions frontend en verde.
3. Captura de SonarCloud con Quality Gate Passed y cobertura.
4. Captura del frontend cargando en producción.
5. Si se corrige: captura del backend con estado saludable.

## Funcionalidades y pruebas
Antes de la defensa, verificar en el código y en los reportes si existen WebSockets/SSE, procesamiento WebP/archivos, modo offline, Vitest, Testcontainers y tres flujos Cypress E2E. No marcarlos como completados sin evidencia.
