# Guion breve de defensa — Huellas Dulces

## 1. Arquitectura y diseño (3 min)
“Huellas Dulces es una solución Full-Stack para la gestión de productos. El frontend Angular consume una API REST desarrollada con Spring Boot. El backend organiza la lógica mediante controladores, servicios y persistencia. PostgreSQL se utiliza como base relacional y JWT protege las operaciones que requieren autenticación.”

## 2. Demostración (5 min)
- Abrir el frontend público.
- Mostrar la navegación y las pantallas realmente disponibles.
- Explicar el flujo de una operación de producto solo si está funcionando.
- Mostrar la llamada al backend únicamente si el servicio está saludable.

## 3. Deep dive técnico (4 min)
“Un componente importante es la autenticación JWT. El cliente envía las credenciales al endpoint de login; el backend valida la solicitud y emite un token. Spring Security utiliza ese token para identificar al usuario y aplicar las reglas de autorización.”

Apoyar la explicación mostrando `AuthController`, `AuthService` y la configuración de seguridad existentes.

## 4. Preguntas (3 min)
- ¿Por qué separar frontend y backend? Para desacoplar presentación y lógica de negocio.
- ¿Qué aporta JWT? Autenticación basada en tokens y autorización por roles.
- ¿Cómo se verifica la calidad? Mediante pruebas automatizadas, JaCoCo y análisis SonarCloud.
- ¿Qué aporta CI/CD? Automatiza verificaciones y reduce errores al integrar cambios.

**Nota:** adaptar el guion a lo que realmente esté implementado y funcionando durante la demostración.
